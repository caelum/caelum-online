package br.com.gnarus.tdd.exercise3;

public class Bankslip {

	private final double amount;
	
	public Bankslip(double amount) {
		this.amount = amount;
	}

	public double getAmount() {
		return amount;
	}
	
}
