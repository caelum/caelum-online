package br.com.gnarus.tdd.exercise3;

public enum PaymentMethod {
	BANKSLIP,
	CREDIT
}
