package br.com.gnarus.tdd.exercise3;

import java.util.List;

public class BankslipProcessor {

	public void process(List<Bankslip> bankslips, Invoice invoice) {
		for(Bankslip boleto : bankslips) {
			Payment newPayment = new Payment(boleto.getAmount(), PaymentMethod.BANKSLIP);
			invoice.getPayments().add(newPayment);
		}
	}
}
