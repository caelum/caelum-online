package br.com.gnarus.tdd.exercise3;

public class Payment {

	private final double amount;
	private final PaymentMethod method;

	public Payment(double amount, PaymentMethod method) {
		this.amount = amount;
		this.method = method;
	}

	public double getAmount() {
		return amount;
	}

	public PaymentMethod getPaymentMethod() {
		return method;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Payment)) {
			return false;
		}
		Payment outro = (Payment) obj;
		if (method != outro.method
				|| Double.doubleToLongBits(amount) != Double
						.doubleToLongBits(outro.amount)) {
			return false;
		}

		return true;
	}

}
