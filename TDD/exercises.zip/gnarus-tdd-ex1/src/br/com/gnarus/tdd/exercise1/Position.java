package br.com.gnarus.tdd.exercise1;

public enum Position {
	DEVELOPER,
	DBA,
	TESTER
}
