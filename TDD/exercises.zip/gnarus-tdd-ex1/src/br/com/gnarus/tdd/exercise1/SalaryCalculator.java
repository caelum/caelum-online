package br.com.gnarus.tdd.exercise1;

import static br.com.gnarus.tdd.exercise1.Position.DBA;
import static br.com.gnarus.tdd.exercise1.Position.DEVELOPER;
import static br.com.gnarus.tdd.exercise1.Position.TESTER;

public class SalaryCalculator {


	public double incomeForA(Employee funcionario) {
		if(DEVELOPER.equals(funcionario.getPosition())) {
			return dezOuVintePorCentoDeDescontoNo(funcionario);
		}
		
		if(DBA.equals(funcionario.getPosition()) || TESTER.equals(funcionario.getPosition())) {
			return quinzeOuVinteECincoPorCentoDeDescontoNo(funcionario);
		}
		
		throw new RuntimeException("funcionario invalido");
	}

	private double dezOuVintePorCentoDeDescontoNo(Employee funcionario) {
		if(funcionario.getBaseSalary() > 3000.0) {
			return funcionario.getBaseSalary() * 0.8;
		}
		else {
			return funcionario.getBaseSalary() * 0.9;
		}
	}

	private double quinzeOuVinteECincoPorCentoDeDescontoNo(Employee funcionario) {
		if(funcionario.getBaseSalary() > 2000.0) {
			return funcionario.getBaseSalary() * 0.75;
		}
		else {
			return funcionario.getBaseSalary() * 0.85;
		}
	}

}
